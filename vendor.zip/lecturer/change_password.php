	<?php include 'lecturer_navbar.php'; ?>
<?php
// lecturer/change_password.php - Lecturer Change Password (Redirect to main)
header('Location: ../change_password.php');
exit();
?>
