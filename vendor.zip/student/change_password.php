<?php
// student/change_password.php - Student Change Password (Redirect to main)
header('Location: ../change_password.php');
exit();
?>
