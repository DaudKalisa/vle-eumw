<?php
// admin/finance_manage_requests.php - Redirect to new location in finance/
header('Location: ../finance/finance_manage_requests.php');
exit;
