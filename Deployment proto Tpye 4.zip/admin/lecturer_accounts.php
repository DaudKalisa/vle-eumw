<?php
// admin/lecturer_accounts.php - Redirect to new location in finance/
header('Location: ../finance/lecturer_accounts.php');
exit;
