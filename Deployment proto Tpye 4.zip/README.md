# Virtual Learning Environment (VLE) System

A standalone web application for managing online courses, built as an independent system that connects to the same database as the main university portal.

## Features

### For Students
- Access enrolled VLE courses
- View weekly course content (presentations, videos, documents, links)
- Submit assignments
- Track progress through course weeks
- Participate in course forums

### For Lecturers
- Create and manage VLE courses
- Add weekly content and assignments
- View student enrollment and progress
- Grade assignments and provide feedback
- Manage course forums

## System Requirements

- PHP 7.4 or higher
- MySQL 5.7 or higher
- Web server (Apache/Nginx)
- Access to the university portal database

## Installation

1. **Database Setup**
   - Ensure the main university portal database is accessible
   - Run the VLE table creation script: `http://localhost/vle_system/setup.php`

2. **Configuration**
   - Update database connection settings in `includes/config.php` if needed
   - Ensure the database credentials match your university portal database

3. **File Permissions**
   - Make sure the `uploads/` directory is writable by the web server
   - Set appropriate permissions for file uploads

## Directory Structure

```
vle_system/
├── includes/           # Core PHP files
│   ├── config.php     # Database configuration
│   ├── auth.php       # Authentication functions
│   └── ...
├── api/               # API endpoints
│   └── vle_actions.php
├── student/           # Student interface
│   └── dashboard.php
├── lecturer/          # Lecturer interface
│   └── dashboard.php
├── assets/            # CSS, JS, images
├── uploads/           # File uploads
├── index.php          # Main entry point
├── login.php          # Login page
└── README.md          # This file
```

## Usage

### Accessing the VLE System

1. Navigate to `http://localhost/vle_system/`
2. Login using your university portal credentials (username or email)
3. Access your courses based on your role (student/lecturer)

### For Lecturers

1. **Creating a Course**
   - Click "Create New Course" from your dashboard
   - Fill in course details (code, name, description)
   - Set total weeks for the course

2. **Adding Content**
   - Select a course and navigate to a specific week
   - Add content items (presentations, videos, documents, etc.)
   - Upload files or provide external links

3. **Managing Assignments**
   - Create assignments for specific weeks
   - Set due dates and grading criteria
   - Review and grade student submissions

### For Students

1. **Accessing Courses**
   - View all enrolled VLE courses on your dashboard
   - Click on a course to access its content

2. **Viewing Content**
   - Content is organized by weeks
   - Access materials as they become available
   - Mark content as viewed to track progress

3. **Submitting Assignments**
   - View assignment details and requirements
   - Submit text responses or upload files
   - Check submission status and grades

## API Endpoints

The VLE system provides RESTful API endpoints for various operations:

- `POST /api/vle_actions.php?action=mark_content_viewed` - Mark content as viewed
- `POST /api/vle_actions.php?action=submit_assignment` - Submit assignment
- `GET /api/vle_actions.php?action=get_course_content` - Get course content
- `GET /api/vle_actions.php?action=get_assignments` - Get course assignments

## Security Features

- Session-based authentication
- Role-based access control
- Input validation and sanitization
- File upload restrictions
- SQL injection prevention

## Database Tables

The VLE system uses the following tables (prefixed with `vle_`):

- `vle_courses` - Course information
- `vle_enrollments` - Student course enrollments
- `vle_weekly_content` - Course content organized by weeks
- `vle_assignments` - Course assignments
- `vle_submissions` - Student assignment submissions
- `vle_progress` - Student progress tracking
- `vle_forums` - Course discussion forums
- `vle_forum_posts` - Forum posts and replies
- `vle_grades` - Grade records
- `attendance_sessions` - Attendance session management
- `attendance_records` - Student attendance records

## Integration with Main Portal

The VLE system integrates with the main university portal by:

- Sharing the same user database
- Using consistent authentication
- Maintaining data relationships through foreign keys
- Allowing seamless access between systems

## Troubleshooting

### Common Issues

1. **Login Issues**
   - Ensure database connection is correct
   - Check that users exist in the main portal database
   - Verify user roles are properly assigned

2. **File Upload Problems**
   - Check upload directory permissions
   - Verify file size limits in PHP configuration
   - Ensure supported file types are allowed

3. **Database Errors**
   - Run the setup script to create VLE tables
   - Check database user permissions
   - Verify foreign key relationships

### Support

For technical support or questions about the VLE system, please contact the system administrator.

## License

This VLE system is part of the university academic portal and follows the same licensing terms.#   v l e - e u m w  
 #   v l e - e u m w  
 #   v l e - e u m w  
 