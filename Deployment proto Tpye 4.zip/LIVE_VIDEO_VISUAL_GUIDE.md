# Live Video Classroom - Visual Guide

## 🎯 System Overview

```
┌─────────────────────────────────────────────────────────────┐
│                    VLE SYSTEM - LIVE VIDEO                  │
└─────────────────────────────────────────────────────────────┘

┌─────────────────────────┐         ┌──────────────────────────┐
│   LECTURER DASHBOARD    │         │   STUDENT DASHBOARD      │
│                         │         │                          │
│ [Live Classroom] ◄──────┼─────────┤─ [Live Classes]         │
│   Button (RED)          │         │   Button (RED)           │
└─────────────────────────┘         └──────────────────────────┘
         │                                      │
         │ Click                                │ Click
         ▼                                      ▼
┌─────────────────────────┐         ┌──────────────────────────┐
│  Live Classroom Page    │         │  Live Invites Page       │
│                         │         │                          │
│ • Start New Session     │         │ • View Active Sessions   │
│ • Active Sessions List  │         │ • Join Meeting Button    │
│ • View Participants     │         │ • View Past Sessions     │
│ • End Session           │         │                          │
└─────────────────────────┘         └──────────────────────────┘
         │                                      │
         │ Submit                               │ Click Join
         ▼                                      ▼
    ┌──────────────────────────────────────────────┐
    │         JITSI MEET VIDEO CONFERENCE          │
    │                                              │
    │  Lecturer ◄──────► Students (Multiple)      │
    │  • Video/Audio                               │
    │  • Screen Share (Jitsi feature)              │
    │  • Chat (Jitsi feature)                      │
    └──────────────────────────────────────────────┘
         │
         │ Session ends
         ▼
    ┌──────────────────────────────────────────────┐
    │         DATABASE RECORDS CREATED             │
    │                                              │
    │  • vle_live_sessions (completed)             │
    │  • vle_session_participants (with times)     │
    │  • vle_session_invites (with status)         │
    └──────────────────────────────────────────────┘
```

---

## 📊 Lecture Session Flow

```
TIMELINE
├─ T=0:00 - Lecturer clicks "Start Live Session"
│  ├─ System creates vle_live_sessions record
│  ├─ Generates unique session code (e.g., "A7F2C9E1")
│  ├─ Creates Jitsi URL: https://meet.jitsi.org/A7F2C9E1
│  ├─ Queries enrolled students from vle_enrollments
│  ├─ Creates vle_session_invites for each student
│  ├─ Creates vle_session_participants records
│  └─ Opens Jitsi Meet in new window
│
├─ T=0:15 - Students see "Live Classes" notification
│  ├─ Student views active invitations
│  ├─ Sees: Course name, Lecturer name, Participant count
│  └─ Shows "LIVE" badge with pulsing animation
│
├─ T=0:20 - First student clicks "Join Meeting"
│  ├─ System updates vle_session_invites (status = "accepted")
│  ├─ Updates vle_session_participants (status = "joined")
│  ├─ Records join_at timestamp
│  └─ Opens Jitsi Meet for student
│
├─ T=0:25 to T=45:00 - More students join
│  └─ Each join is recorded with timestamp
│
├─ T=45:00 - Lecturer finishes class
│  ├─ Lecturer clicks "End Session"
│  ├─ System updates vle_live_sessions (status = "completed")
│  ├─ Records ended_at timestamp
│  └─ Session moves to history
│
└─ AFTER - Session appears in "Past Sessions"
   ├─ Students see it in history
   ├─ Shows attendance timestamps
   └─ Shows "Completed" badge
```

---

## 🖼️ UI Layout - Lecturer

### Live Classroom Page
```
┌─────────────────────────────────────────────────────┐
│ [←Back] Live Classroom              [Other buttons] │
└─────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────┐
│  🎥 Start Live Class                                │
│  Connect with your students in real-time            │
└─────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────┐
│ ⊕ Start New Live Session                            │
├─────────────────────────────────────────────────────┤
│                                                     │
│ Select Course    │ Session Topic/Name              │
│ ┌──────────────┐ │ ┌─────────────────────────┐     │
│ │ Course A ▼   │ │ │ Lecture 5: Topics...    │     │
│ └──────────────┘ │ └─────────────────────────┘     │
│                  │                                 │
│ Note: All enrolled students will receive an invite │
│                                                     │
│         [Start Live Session]                        │
│                                                     │
└─────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────┐
│ ◎ Active Live Sessions                [🔴 LIVE]   │
├─────────────────────────────────────────────────────┤
│                                                     │
│ ┌─────────────────────┐  ┌──────────────────────┐  │
│ │ Lecture 5: Topics   │  │ Lecture 4: Review    │  │
│ │ 🔴 LIVE            │  │ 🔴 LIVE             │  │
│ │ Course A           │  │ Course B            │  │
│ │ ◆ 12 Active / 25   │  │ ◆ 8 Active / 30     │  │
│ │ Started: 10:45     │  │ Started: 10:30      │  │
│ │                    │  │                     │  │
│ │ [Join] [Partici..] │  │ [Join] [Partici..] │  │
│ │        [End]       │  │        [End]        │  │
│ └─────────────────────┘  └──────────────────────┘  │
│                                                     │
└─────────────────────────────────────────────────────┘
```

---

## 🖼️ UI Layout - Student

### Live Classes / Invites Page
```
┌─────────────────────────────────────────────────────┐
│ [←Back] Live Classroom Invites      [Other buttons] │
└─────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────┐
│ 🔔 Active Live Sessions           [🔴 LIVE 2 ACTIVE]│
├─────────────────────────────────────────────────────┤
│                                                     │
│ ┌────────────────────────────────────────────────┐ │
│ │ Lecture 5: Advanced Topics      [🔴 LIVE]     │ │
│ │                                                │ │
│ │ 👤 Dr. John Smith (Lecturer)                   │ │
│ │ 📚 Course A                                    │ │
│ │                                                │ │
│ │ ◆ 12 currently online                          │ │
│ │ ⏱ Started 10:45 AM                             │ │
│ │ 🏷 [sent]  ◆ [25 invited]                      │ │
│ │                                                │ │
│ │     [Join Meeting] [Details]                   │ │
│ └────────────────────────────────────────────────┘ │
│                                                     │
│ ┌────────────────────────────────────────────────┐ │
│ │ Lecture 3: Fundamentals         [🔴 LIVE]     │ │
│ │ ...                                            │ │
│ └────────────────────────────────────────────────┘ │
│                                                     │
└─────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────┐
│ 🕐 Past Sessions                                    │
├─────────────────────────────────────────────────────┤
│                                                     │
│ Lecture 2: Introduction                  [Completed]│
│ Course A | Dr. John Smith                          │
│ Attended: Jan 25, 10:15 - 11:00                    │
│                                                     │
│ ... more past sessions ...                          │
│                                                     │
└─────────────────────────────────────────────────────┘
```

---

## 📱 Status Badge States

```
┌─────────────────────────────────────────┐
│  INVITATION STATUS PROGRESSION           │
├─────────────────────────────────────────┤
│                                         │
│  [sent]   →   [viewed]   →   [accepted]│
│                              ↓         │
│                           [joined]     │
│                                         │
│  Colors:                                │
│  🟡 sent/new (yellow)                   │
│  🔵 viewed (blue)                       │
│  🟢 accepted/joined (green)             │
│  ⚪ completed (gray)                     │
│                                         │
└─────────────────────────────────────────┘
```

---

## 🔄 Data Flow Diagram

```
┌──────────────────────────────────────────────────────────┐
│            LECTURER STARTS SESSION                       │
└──────────────────────────────────────────────────────────┘
                         ▼
            ┌─────────────────────────┐
            │  live_classroom.php     │
            │  • Form submission      │
            │  • Course validation    │
            └─────────────────────────┘
                         ▼
            ┌─────────────────────────┐
            │   live_session_api.php  │
            │   action=start_session  │
            └─────────────────────────┘
                         ▼
    ┌────────────────────────────────────────┐
    │    CREATE DATABASE RECORDS             │
    ├────────────────────────────────────────┤
    │                                        │
    │ 1. INSERT vle_live_sessions            │
    │    • Generate session_code             │
    │    • Generate Jitsi URL                │
    │    • Set status = 'active'             │
    │                                        │
    │ 2. QUERY vle_enrollments               │
    │    • Get all students in course        │
    │                                        │
    │ 3. INSERT vle_session_participants     │
    │    • For each enrolled student         │
    │    • Set status = 'invited'            │
    │                                        │
    │ 4. INSERT vle_session_invites          │
    │    • For each enrolled student         │
    │    • Set status = 'sent'               │
    │                                        │
    └────────────────────────────────────────┘
                         ▼
            ┌─────────────────────────┐
            │ RESPONSE WITH JITSI URL │
            │ + Open meeting window   │
            └─────────────────────────┘


┌──────────────────────────────────────────────────────────┐
│            STUDENT RECEIVES & JOINS                      │
└──────────────────────────────────────────────────────────┘
                         ▼
    ┌──────────────────────────────────────┐
    │ Browser loads live_invites.php       │
    │ Query: SELECT * FROM vle_session_... │
    │ Result: Active invitations displayed │
    └──────────────────────────────────────┘
                         ▼
    ┌──────────────────────────────────────┐
    │  Student clicks [Join Meeting]       │
    └──────────────────────────────────────┘
                         ▼
    ┌──────────────────────────────────────┐
    │  live_session_api.php                │
    │  action=accept_invite                │
    └──────────────────────────────────────┘
                         ▼
    ┌────────────────────────────────────────┐
    │    UPDATE DATABASE RECORDS             │
    ├────────────────────────────────────────┤
    │                                        │
    │ 1. UPDATE vle_session_invites          │
    │    • status = 'accepted'               │
    │    • accepted_at = NOW()               │
    │    • viewed_at = NOW()                 │
    │                                        │
    │ 2. UPDATE vle_session_participants     │
    │    • status = 'joined'                 │
    │    • joined_at = NOW()                 │
    │                                        │
    └────────────────────────────────────────┘
                         ▼
    ┌──────────────────────────────────────┐
    │ Return Jitsi URL                     │
    │ Open in new window                   │
    │ Student joins video conference       │
    └──────────────────────────────────────┘
```

---

## 🗂️ Database Relationships

```
┌──────────────────────────┐
│  vle_courses             │
│  • course_id (PK)        │
│  • lecturer_id (FK) ────┐│
└──────────────────────────┘│
         ▲                   │
         │ (1 to many)       │
┌────────┴──────────────────┐
│  vle_enrollments          │
│  • enrollment_id (PK)     │
│  • course_id (FK) ────────┤──┐
│  • student_id (FK)        │  │
└───────────────────────────┘  │
         ▲                      │
         │                      │
         │ (1 to many)          │
    ┌────┴──────────────┐       │
    │ (students)        │       │
    │ (users)           │       │
    └───────────────────┘       │
                                │
        vle_live_sessions       │
        • session_id (PK)       │
        • course_id (FK) ───────┘
        • lecturer_id (FK) ──┐
        • session_code       │
        • status             │
        └─────────────────────┐
                              │
         ┌────────────────────┴────────────────┐
         ▼                                      ▼
  vle_session_participants      vle_session_invites
  • participant_id (PK)         • invite_id (PK)
  • session_id (FK)             • session_id (FK)
  • student_id (FK)             • student_id (FK)
  • status                       • status
  • joined_at                    • accepted_at
  • left_at                      • viewed_at
         ▲                              ▲
         └──────────── both link to students ──┘
```

---

## 🚀 Session Lifecycle

```
TIME →

PENDING              ACTIVE                  COMPLETED
[Scheduled]      [In Progress]           [Finished]

    │                  │                      │
    ├─ Create          ├─ Students join       ├─ End time set
    │  session         │  Record timestamps   │  Status changed
    │  Send invites    │  Track participants  │  Archive for
    │  Wait for        │  Lecturer monitors   │  history
    │  start time      │  Real-time count    │
    │                  │                      │
    └──────────────────┴──────────────────────┘

Database Status Progression:
    'pending' → 'active' → 'completed'

Invite Status:
    'sent' → 'viewed' → 'accepted'

Participant Status:
    'invited' → 'joined' → 'left'
```

---

## 🔐 Security Flow

```
┌─────────────────────────────────────────┐
│         USER LOGIN REQUEST               │
└─────────────────────────────────────────┘
                ▼
┌─────────────────────────────────────────┐
│    Check Authentication (auth.php)      │
│    • Session valid?                     │
│    • User logged in?                    │
└─────────────────────────────────────────┘
                ▼
            ┌────────┐
            │ PASS?  │
            └────┬───┘
         NO /    \ YES
        ────      ────
        ▼          ▼
    [REJECT]  ┌───────────────────────┐
              │ Check Role            │
              │ • Lecturer?           │
              │ • Student?            │
              └────┬──────┬───────────┘
                   │      │
              LECTURER  STUDENT
                ▼         ▼
            Access    Access
            Lecturer  Student
            Pages     Pages
              │         │
              ▼         ▼
          ┌─────────────────────┐
          │ Verify Ownership     │
          │ Lecturers: Own       │
          │ course check        │
          │ Students: Enrolled   │
          │ in course check      │
          └────────┬─────────────┘
                   │
                   ▼
          ┌─────────────────────┐
          │ FULL ACCESS GRANTED │
          └─────────────────────┘
```

---

## 📊 Key Metrics Tracked

```
Per Session:
├─ Total invites sent
├─ Accepted invites
├─ Students who joined
├─ Time each student joined
├─ Time each student left
├─ Session duration
└─ Peak concurrent participants

Per Student:
├─ Sessions invited to
├─ Sessions accepted
├─ Sessions attended
├─ Total attendance hours
├─ Attendance rate
└─ Average join time after invite
```

---

**This visual guide helps understand the complete flow of the live video classroom system!**
